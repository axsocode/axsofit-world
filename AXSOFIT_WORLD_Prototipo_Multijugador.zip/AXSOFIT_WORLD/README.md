# AXSOFIT WORLD — prototipo de avatar multijugador

## Incluye
- Modelo GLB humanoide AXSOFIT con skinning y clips integrados.
- Visor 3D Three.js / React Three Fiber.
- Caminar con WASD/flechas, gesto Saludar (H), Celebrar (C), detener y recentrar.
- Control de velocidad de animación.
- Adaptador Supabase Realtime para presencia y broadcast de estados de jugadores.
- Modo demostración local cuando no hay credenciales.

## Ejecutar
1. Instala Node.js 20 o superior.
2. Copia `.env.example` como `.env` y añade URL y anon key de Supabase si vas a probar red.
3. Ejecuta `npm install`.
4. Ejecuta `npm run dev`.
5. Abre la URL local que muestra Vite.

## Multijugador real
Crea un proyecto Supabase y habilita Realtime. Añade `VITE_SUPABASE_URL` y `VITE_SUPABASE_ANON_KEY` al entorno. El prototipo utiliza un canal público `axsofit-world-room-01` con Presence y Broadcast. Para producción:
- Restringir el acceso al canal con políticas de Realtime Authorization.
- Autenticar usuarios; no confiar en playerId enviado por el cliente.
- Validar payloads y limitar frecuencia/tamaño de mensajes.
- Implementar autoridad del servidor para movimiento y acciones.
- Añadir interpolación/extrapolación de estados remotos, reconexión y limpieza de jugadores desconectados.
- Configurar reloj de servidor y calcular offset de cada cliente para sincronización estricta.

## Nota técnica
El rig adjunto es una primera versión procedural. Los pesos automáticos pueden necesitar correcciones en hombros, caderas, codos y rodillas. La malla anatómica original está compuesta por volúmenes superpuestos; para producción se recomienda remesh, retopología y revisión de deformaciones.
