# AXSOFIT WORLD — prototipo de avatar multijugador

## Incluye
- Modelo GLB humanoide AXSOFIT con skinning y clips integrados.
- Visor 3D Three.js / React Three Fiber.
- Caminar con WASD/flechas, gesto Saludar (H), Celebrar (C), detener y recentrar.
- Control de velocidad de animación.
- Adaptador Supabase Realtime para presencia y broadcast de estados de jugadores.
- Modo demostración local cuando no hay credenciales.

## Ejecutar
1. Instala Node.js 20 o superior.
2. Copia `.env.example` como `.env` y añade URL y anon key de Supabase si vas a probar red.
3. Ejecuta `npm install`.
4. Ejecuta `npm run dev`.
5. Abre la URL local que muestra Vite.

## Multijugador real
Crea un proyecto Supabase y habilita Realtime. Añade `VITE_SUPABASE_URL` y `VITE_SUPABASE_ANON_KEY` al entorno. El prototipo utiliza un canal público `axsofit-world-room-01` con Presence y Broadcast. Para producción:
- Restringir el acceso al canal con políticas de Realtime Authorization.
- Autenticar usuarios; no confiar en playerId enviado por el cliente.
- Validar payloads y limitar frecuencia/tamaño de mensajes.
- Implementar autoridad del servidor para movimiento y acciones.
- Añadir interpolación/extrapolación de estados remotos, reconexión y limpieza de jugadores desconectados.
- Configurar reloj de servidor y calcular offset de cada cliente para sincronización estricta.

## Nota técnica
El rig adjunto es una primera versión procedural. Los pesos automáticos pueden necesitar correcciones en hombros, caderas, codos y rodillas. La malla anatómica original está compuesta por volúmenes superpuestos; para producción se recomienda remesh, retopología y revisión de deformaciones.

## Perfil RPG del atleta (actualización)
El perfil lateral incorpora seis pestañas: Avatar, Composición corporal, Fuerza, Resistencia, AXcircuit y Estadísticas. La vista de estadísticas incluye un pentagrama de cinco atributos (fuerza, resistencia, recuperación, velocidad y agilidad), además de nivel, rango y barra de experiencia.

Los datos numéricos mostrados en las pantallas RPG son valores de demostración para diseñar la interfaz. Deben conectarse a mediciones y sesiones reales antes de usarse para clasificaciones o decisiones de entrenamiento. Los módulos de alta de mediciones, rutinas y desafíos muestran acciones de demostración; todavía requieren persistencia y formularios conectados a una base de datos.

## Perfil RPG ampliado: métricas de salud y actividad

El perfil incorpora pestañas adicionales para:
- Cardio: frecuencia cardíaca media/máxima, distribución del tiempo por zonas y carga de sesión.
- Actividad: pasos, distancia, calorías activas, minutos activos, objetivos diarios y racha semanal.
- Historial: sesiones y filtros temporales día/semana/mes/año.
- Logros: camino de rangos, hitos y medallas.
- Composición corporal: espacio para análisis segmental de tronco, brazos y piernas.

Los valores visibles en estas nuevas pantallas son datos demostrativos para maquetación, no datos importados de dispositivos. La integración real con Polar, Myzone, InBody, Google Fit/Health Connect y la persistencia de registros requiere conectar sus APIs o importadores y definir permisos de usuario.

## Academia AXSOFIT: progresión por ciclos

La pestaña **ACADEMIA** incorpora una ruta demostrativa de entrenamiento organizada en macrociclo, mesociclos y microciclos. Incluye misiones con XP, desbloqueo secuencial de semanas y estado de misión completada. La plantilla inicial ilustra adaptación, desarrollo y consolidación; debe personalizarse según evaluación inicial, objetivo, disponibilidad, experiencia, recuperación y respuesta individual.

La XP y los desbloqueos son gamificación: no sustituyen criterios de seguridad ni justifican aumentar la carga automáticamente. En una versión conectada, las misiones deberán completarse a partir de sesiones registradas y verificadas, no solo pulsando el botón de completar.
